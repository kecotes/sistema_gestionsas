
<!-- Actaparcial Field -->
<div class="form-group">
    {!! Form::label('actaparcial', 'Actaparcial:') !!}
    <p>{!! $balancesfinancieros->actaparcial !!}</p>
</div>

<!-- Pendientepagar Field -->
<div class="form-group">
    {!! Form::label('pendientepagar', 'Pendientepagar:') !!}
    <p>{!! $balancesfinancieros->pendientepagar !!}</p>
</div>

<!-- Estado Field -->
<div class="form-group">
    {!! Form::label('estado', 'Estado:') !!}
    <p>{!! $balancesfinancieros->estado !!}</p>
</div>

<!-- Created At Field -->
<div class="form-group">
    {!! Form::label('created_at', 'Fecha de Creacion:') !!}
    <p>{!! $balancesfinancieros->created_at !!}</p>
</div>
