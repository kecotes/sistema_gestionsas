<!-- Id Field -->
<div class="form-group">
    {!! Form::label('id', 'Id:') !!}
    <p>{!! $datosejecucionfisicofinanciera->id !!}</p>
</div>

<!-- Item Field -->
<div class="form-group">
    {!! Form::label('item', 'Item:') !!}
    <p>{!! $datosejecucionfisicofinanciera->item !!}</p>
</div>

<!-- Tema Field -->
<div class="form-group">
    {!! Form::label('tema', 'Tema:') !!}
    <p>{!! $datosejecucionfisicofinanciera->tema !!}</p>
</div>

<!-- Descripcion Field -->
<div class="form-group">
    {!! Form::label('descripcion', 'Descripcion:') !!}
    <p>{!! $datosejecucionfisicofinanciera->descripcion !!}</p>
</div>

<!-- Ejecucionacumitem Field -->
<div class="form-group">
    {!! Form::label('ejecucionacumitem', 'Ejecucionacumitem:') !!}
    <p>{!! $datosejecucionfisicofinanciera->ejecucionacumitem !!}</p>
</div>

<!-- Estado Field -->
<div class="form-group">
    {!! Form::label('estado', 'Estado:') !!}
    <p>{!! $datosejecucionfisicofinanciera->estado !!}</p>
</div>

<!-- Idcontratos Field -->
<div class="form-group">
    {!! Form::label('idcontratos', 'Idcontratos:') !!}
    <p>{!! $datosejecucionfisicofinanciera->idcontratos !!}</p>
</div>

<!-- Created At Field -->
<div class="form-group">
    {!! Form::label('created_at', 'Created At:') !!}
    <p>{!! $datosejecucionfisicofinanciera->created_at !!}</p>
</div>

<!-- Updated At Field -->
<div class="form-group">
    {!! Form::label('updated_at', 'Updated At:') !!}
    <p>{!! $datosejecucionfisicofinanciera->updated_at !!}</p>
</div>

