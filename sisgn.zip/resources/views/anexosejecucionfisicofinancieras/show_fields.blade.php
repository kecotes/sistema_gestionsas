<!-- Id Field -->
<div class="form-group">
    {!! Form::label('id', 'Id:') !!}
    <p>{!! $anexosejecucionfisicofinanciera->id !!}</p>
</div>

<!-- Administracion Field -->
<div class="form-group">
    {!! Form::label('administracion', 'Administracion:') !!}
    <p>{!! $anexosejecucionfisicofinanciera->administracion !!}</p>
</div>

<!-- Administracionporcentaje Field -->
<div class="form-group">
    {!! Form::label('administracionporcentaje', 'Administracionporcentaje:') !!}
    <p>{!! $anexosejecucionfisicofinanciera->administracionporcentaje !!}</p>
</div>

<!-- Imprevisto Field -->
<div class="form-group">
    {!! Form::label('imprevisto', 'Imprevisto:') !!}
    <p>{!! $anexosejecucionfisicofinanciera->imprevisto !!}</p>
</div>

<!-- Imprevistoporcentaje Field -->
<div class="form-group">
    {!! Form::label('imprevistoporcentaje', 'Imprevistoporcentaje:') !!}
    <p>{!! $anexosejecucionfisicofinanciera->imprevistoporcentaje !!}</p>
</div>

<!-- Iddatosejecucion Field -->
<div class="form-group">
    {!! Form::label('iddatosejecucion', 'Iddatosejecucion:') !!}
    <p>{!! $anexosejecucionfisicofinanciera->iddatosejecucion !!}</p>
</div>

<!-- Created At Field -->
<div class="form-group">
    {!! Form::label('created_at', 'Created At:') !!}
    <p>{!! $anexosejecucionfisicofinanciera->created_at !!}</p>
</div>

<!-- Updated At Field -->
<div class="form-group">
    {!! Form::label('updated_at', 'Updated At:') !!}
    <p>{!! $anexosejecucionfisicofinanciera->updated_at !!}</p>
</div>

