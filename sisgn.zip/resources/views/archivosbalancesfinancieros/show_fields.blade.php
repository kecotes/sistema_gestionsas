<!-- Id Field -->
<div class="form-group">
    {!! Form::label('id', 'Id:') !!}
    <p>{!! $archivosbalancesfinancieros->id !!}</p>
</div>

<!-- Archivo Field -->
<div class="form-group">
    {!! Form::label('archivo', 'Archivo:') !!}
    <p>{!! $archivosbalancesfinancieros->archivo !!}</p>
</div>

<!-- Titulo Field -->
<div class="form-group">
    {!! Form::label('titulo', 'Titulo:') !!}
    <p>{!! $archivosbalancesfinancieros->titulo !!}</p>
</div>

<!-- Descripcion Field -->
<div class="form-group">
    {!! Form::label('descripcion', 'Descripcion:') !!}
    <p>{!! $archivosbalancesfinancieros->descripcion !!}</p>
</div>

<!-- Idbalancesfinancieros Field -->
<div class="form-group">
    {!! Form::label('idbalancesfinancieros', 'Idbalancesfinancieros:') !!}
    <p>{!! $archivosbalancesfinancieros->idbalancesfinancieros !!}</p>
</div>

<!-- Created At Field -->
<div class="form-group">
    {!! Form::label('created_at', 'Created At:') !!}
    <p>{!! $archivosbalancesfinancieros->created_at !!}</p>
</div>

<!-- Updated At Field -->
<div class="form-group">
    {!! Form::label('updated_at', 'Updated At:') !!}
    <p>{!! $archivosbalancesfinancieros->updated_at !!}</p>
</div>

