<!-- Id Field -->
<div class="form-group">
    {!! Form::label('id', 'Id:') !!}
    <p>{!! $actividadescontratos->id !!}</p>
</div>

<!-- Titulo Field -->
<div class="form-group">
    {!! Form::label('titulo', 'Titulo:') !!}
    <p>{!! $actividadescontratos->titulo !!}</p>
</div>

<!-- Contenido Field -->
<div class="form-group">
    {!! Form::label('contenido', 'Contenido:') !!}
    <p>{!! $actividadescontratos->contenido !!}</p>
</div>

<!-- Estado Field -->
<div class="form-group">
    {!! Form::label('estado', 'Estado:') !!}
    <p>{!! $actividadescontratos->estado !!}</p>
</div>

<!-- Idcontratos Field -->
<div class="form-group">
    {!! Form::label('idcontratos', 'Idcontratos:') !!}
    <p>{!! $actividadescontratos->idcontratos !!}</p>
</div>

<!-- Idtipoactividades Field -->
<div class="form-group">
    {!! Form::label('idtipoactividades', 'Idtipoactividades:') !!}
    <p>{!! $actividadescontratos->idtipoactividades !!}</p>
</div>

<!-- Created At Field -->
<div class="form-group">
    {!! Form::label('created_at', 'Created At:') !!}
    <p>{!! $actividadescontratos->created_at !!}</p>
</div>

<!-- Updated At Field -->
<div class="form-group">
    {!! Form::label('updated_at', 'Updated At:') !!}
    <p>{!! $actividadescontratos->updated_at !!}</p>
</div>

