<!-- Id Field -->
<div class="form-group">
    {!! Form::label('id', 'Id:') !!}
    <p>{!! $anexosfisicofinanciera->id !!}</p>
</div>

<!-- Administracion Field -->
<div class="form-group">
    {!! Form::label('administracion', 'Administracion:') !!}
    <p>{!! $anexosfisicofinanciera->administracion !!}</p>
</div>

<!-- Administracionporcentaje Field -->
<div class="form-group">
    {!! Form::label('administracionporcentaje', 'Administracionporcentaje:') !!}
    <p>{!! $anexosfisicofinanciera->administracionporcentaje !!}</p>
</div>

<!-- Imprevisto Field -->
<div class="form-group">
    {!! Form::label('imprevisto', 'Imprevisto:') !!}
    <p>{!! $anexosfisicofinanciera->imprevisto !!}</p>
</div>

<!-- Imprevistoporcentaje Field -->
<div class="form-group">
    {!! Form::label('imprevistoporcentaje', 'Imprevistoporcentaje:') !!}
    <p>{!! $anexosfisicofinanciera->imprevistoporcentaje !!}</p>
</div>

<!-- Iddatosejecucion Field -->
<div class="form-group">
    {!! Form::label('iddatosejecucion', 'Iddatosejecucion:') !!}
    <p>{!! $anexosfisicofinanciera->iddatosejecucion !!}</p>
</div>

<!-- Created At Field -->
<div class="form-group">
    {!! Form::label('created_at', 'Created At:') !!}
    <p>{!! $anexosfisicofinanciera->created_at !!}</p>
</div>

<!-- Updated At Field -->
<div class="form-group">
    {!! Form::label('updated_at', 'Updated At:') !!}
    <p>{!! $anexosfisicofinanciera->updated_at !!}</p>
</div>

