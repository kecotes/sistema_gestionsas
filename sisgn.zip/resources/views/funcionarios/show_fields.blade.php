<!-- Id Field -->
<div class="form-group">
    {!! Form::label('id', 'Id:') !!}
    <p>{!! $funcionarios->id !!}</p>
</div>

<!-- Nombre Field -->
<div class="form-group">
    {!! Form::label('nombre', 'Nombre:') !!}
    <p>{!! $funcionarios->nombre !!}</p>
</div>

<!-- Apellido Field -->
<div class="form-group">
    {!! Form::label('apellido', 'Apellido:') !!}
    <p>{!! $funcionarios->apellido !!}</p>
</div>

<!-- Tipofuncionario Field -->
<div class="form-group">
    {!! Form::label('tipofuncionario', 'Tipofuncionario:') !!}
    <p>{!! $funcionarios->tipofuncionario !!}</p>
</div>

<!-- Usuario Field -->
<div class="form-group">
    {!! Form::label('usuario', 'Usuario:') !!}
    <p>{!! $funcionarios->usuario !!}</p>
</div>

<!-- Contrasena Field -->
<div class="form-group">
    {!! Form::label('contrasena', 'Contrasena:') !!}
    <p>{!! $funcionarios->contrasena !!}</p>
</div>

<!-- Idpnaturales Field -->
<div class="form-group">
    {!! Form::label('idpnaturales', 'Idpnaturales:') !!}
    <p>{!! $funcionarios->idpnaturales !!}</p>
</div>

<!-- Created At Field -->
<div class="form-group">
    {!! Form::label('created_at', 'Created At:') !!}
    <p>{!! $funcionarios->created_at !!}</p>
</div>

<!-- Updated At Field -->
<div class="form-group">
    {!! Form::label('updated_at', 'Updated At:') !!}
    <p>{!! $funcionarios->updated_at !!}</p>
</div>

