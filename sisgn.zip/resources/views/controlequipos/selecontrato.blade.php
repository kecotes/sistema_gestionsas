@extends('layouts.app')

@section('content')
    <section class="content-header">
      <h1><a class="btn btn-info" href="index/1">seleccione contrato</a> 
        <small></small>
      </h1>

@endsection
