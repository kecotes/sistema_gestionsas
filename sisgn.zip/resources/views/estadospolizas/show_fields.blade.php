
<!-- Amparo Field -->
<div class="form-group">
    {!! Form::label('amparo', 'Amparo:') !!}
    <p>{!! $estadospolizas->amparo !!}</p>
</div>

<!-- Vigenciadesde Field -->
<div class="form-group">
    {!! Form::label('vigenciadesde', 'Vigencia desde:') !!}
    <p>{!! $estadospolizas->vigenciadesde !!}</p>
</div>

<!-- Vigenciahasta Field -->
<div class="form-group">
    {!! Form::label('vigenciahasta', 'Vigencia hasta:') !!}
    <p>{!! $estadospolizas->vigenciahasta !!}</p>
</div>

<!-- Valorasegurado Field -->
<div class="form-group">
    {!! Form::label('valorasegurado', 'Valor asegurado:') !!}
    <p>{!! $estadospolizas->valorasegurado !!}</p>
</div>

<!-- Estadopoliza Field -->
<div class="form-group">
    {!! Form::label('estadopoliza', 'Estado de la poliza:') !!}
    <p>{!! $estadospolizas->estadopoliza !!}</p>
</div>

<!-- Created At Field -->
<div class="form-group">
    {!! Form::label('created_at', 'Fecha de Creacion:') !!}
    <p>{!! $estadospolizas->created_at !!}</p>
</div>

