<!-- Id Field -->
<div class="form-group">
    {!! Form::label('id', 'Id:') !!}
    <p>{!! $contratosprue->id !!}</p>
</div>

<!-- Entidadcontratante Field -->
<div class="form-group">
    {!! Form::label('entidadcontratante', 'Entidadcontratante:') !!}
    <p>{!! $contratosprue->entidadcontratante !!}</p>
</div>

<!-- Objetocontrato Field -->
<div class="form-group">
    {!! Form::label('objetocontrato', 'Objetocontrato:') !!}
    <p>{!! $contratosprue->objetocontrato !!}</p>
</div>

<!-- Nocontrato Field -->
<div class="form-group">
    {!! Form::label('nocontrato', 'Nocontrato:') !!}
    <p>{!! $contratosprue->nocontrato !!}</p>
</div>

<!-- Ncontrato Field -->
<div class="form-group">
    {!! Form::label('ncontrato', 'Ncontrato:') !!}
    <p>{!! $contratosprue->ncontrato !!}</p>
</div>

<!-- Apodocontrato Field -->
<div class="form-group">
    {!! Form::label('apodocontrato', 'Apodocontrato:') !!}
    <p>{!! $contratosprue->apodocontrato !!}</p>
</div>

<!-- Valorcontratol Field -->
<div class="form-group">
    {!! Form::label('valorcontratol', 'Valorcontratol:') !!}
    <p>{!! $contratosprue->valorcontratol !!}</p>
</div>

<!-- Valorcontrato Field -->
<div class="form-group">
    {!! Form::label('valorcontrato', 'Valorcontrato:') !!}
    <p>{!! $contratosprue->valorcontrato !!}</p>
</div>

<!-- Valoranticipol Field -->
<div class="form-group">
    {!! Form::label('valoranticipol', 'Valoranticipol:') !!}
    <p>{!! $contratosprue->valoranticipol !!}</p>
</div>

<!-- Valoranticipo Field -->
<div class="form-group">
    {!! Form::label('valoranticipo', 'Valoranticipo:') !!}
    <p>{!! $contratosprue->valoranticipo !!}</p>
</div>

<!-- Porcentajeanticipo Field -->
<div class="form-group">
    {!! Form::label('porcentajeanticipo', 'Porcentajeanticipo:') !!}
    <p>{!! $contratosprue->porcentajeanticipo !!}</p>
</div>

<!-- Formapago Field -->
<div class="form-group">
    {!! Form::label('formapago', 'Formapago:') !!}
    <p>{!! $contratosprue->formapago !!}</p>
</div>

<!-- Valoradicional Field -->
<div class="form-group">
    {!! Form::label('valoradicional', 'Valoradicional:') !!}
    <p>{!! $contratosprue->valoradicional !!}</p>
</div>

<!-- Valoranticipoadicional Field -->
<div class="form-group">
    {!! Form::label('valoranticipoadicional', 'Valoranticipoadicional:') !!}
    <p>{!! $contratosprue->valoranticipoadicional !!}</p>
</div>

<!-- Plazoinicial Field -->
<div class="form-group">
    {!! Form::label('plazoinicial', 'Plazoinicial:') !!}
    <p>{!! $contratosprue->plazoinicial !!}</p>
</div>

<!-- Fechainiciacion Field -->
<div class="form-group">
    {!! Form::label('fechainiciacion', 'Fechainiciacion:') !!}
    <p>{!! $contratosprue->fechainiciacion !!}</p>
</div>

<!-- Fechafinalizacion Field -->
<div class="form-group">
    {!! Form::label('fechafinalizacion', 'Fechafinalizacion:') !!}
    <p>{!! $contratosprue->fechafinalizacion !!}</p>
</div>

<!-- Tipocontrato Field -->
<div class="form-group">
    {!! Form::label('tipocontrato', 'Tipocontrato:') !!}
    <p>{!! $contratosprue->tipocontrato !!}</p>
</div>

<!-- Estado Field -->
<div class="form-group">
    {!! Form::label('estado', 'Estado:') !!}
    <p>{!! $contratosprue->estado !!}</p>
</div>

<!-- Idpersonas Field -->
<div class="form-group">
    {!! Form::label('idpersonas', 'Idpersonas:') !!}
    <p>{!! $contratosprue->idpersonas !!}</p>
</div>

<!-- Identidadescontratantes Field -->
<div class="form-group">
    {!! Form::label('identidadescontratantes', 'Identidadescontratantes:') !!}
    <p>{!! $contratosprue->identidadescontratantes !!}</p>
</div>

<!-- Idtiposcontratos Field -->
<div class="form-group">
    {!! Form::label('idtiposcontratos', 'Idtiposcontratos:') !!}
    <p>{!! $contratosprue->idtiposcontratos !!}</p>
</div>

<!-- Created At Field -->
<div class="form-group">
    {!! Form::label('created_at', 'Created At:') !!}
    <p>{!! $contratosprue->created_at !!}</p>
</div>

<!-- Updated At Field -->
<div class="form-group">
    {!! Form::label('updated_at', 'Updated At:') !!}
    <p>{!! $contratosprue->updated_at !!}</p>
</div>

